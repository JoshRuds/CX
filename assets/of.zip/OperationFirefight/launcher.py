def launcher():
    import pygame
    import sys
    import os
    # Initialize Pygame
    pygame.init()

    # Constants
    WIDTH, HEIGHT = 400, 300
    BACKGROUND_COLOR = (30, 30, 30)
    BUTTON_COLOR = (70, 70, 70)
    BUTTON_HOVER_COLOR = (100, 100, 100)
    FONT_COLOR = (255, 255, 255)

    # Set up the display
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Operation Firefight Launcher")

    # Load font
    font = pygame.font.Font(None, 36)

    # Button class
    class Button:
        def __init__(self, text, x, y, width, height):
            self.text = text
            self.rect = pygame.Rect(x, y, width, height)

        def draw(self, screen):
            mouse_pos = pygame.mouse.get_pos()
            if self.rect.collidepoint(mouse_pos):
                pygame.draw.rect(screen, BUTTON_HOVER_COLOR, self.rect)
            else:
                pygame.draw.rect(screen, BUTTON_COLOR, self.rect)
            
            text_surface = font.render(self.text, True, FONT_COLOR)
            text_rect = text_surface.get_rect(center=self.rect.center)
            screen.blit(text_surface, text_rect)

        def is_clicked(self):
            mouse_click = pygame.mouse.get_pressed()
            return mouse_click[0] and self.rect.collidepoint(pygame.mouse.get_pos())

    # Create buttons
    run_game_button = Button("Run Game", 100, 50, 200, 50)
    settings_button = Button("Keybinds", 100, 120, 200, 50)
    quit_button = Button("Quit", 100, 190, 200, 50)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BACKGROUND_COLOR)

        # Draw buttons
        run_game_button.draw(screen)
        settings_button.draw(screen)
        quit_button.draw(screen)

        # Check button clicks
        if run_game_button.is_clicked():
            return True
        elif settings_button.is_clicked():
            return False
        elif quit_button.is_clicked():
            return None

        pygame.display.flip()