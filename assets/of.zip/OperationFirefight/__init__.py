# string the key in a file
from cryptography.fernet import Fernet
key = Fernet.generate_key()
with open('filekey.key', 'wb') as filekey:
   filekey.write(key)
try:
   open('save_data.dat', 'x')
except FileExistsError:
   pass