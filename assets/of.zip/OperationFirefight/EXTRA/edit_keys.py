import json

def save_keys(data):
    with open('keys_save.json', 'w') as f:
        f.write(json.dumps(data))

def load_keys():
    with open('keys_save.json', 'r') as f:
        data = f.read()
    data = json.loads(data)
    return data

def set_item_key(for_item, data):

    # Prompt the user for a value
    new = input("Please enter a value for the key '{}': ".format(for_item))

    if new == '':
        return

    # Set the key-value pair in the dictionary
    data[for_item] = new

    # Display the resulting item
    print(f"The key for {for_item} has been set to {new}")

if __name__ == "__main__":
    data = load_keys()
    print('Choose the new key. Type help for list of keys')
    print('Press enter to skip')
    for item in data:
        set_item_key(item,data)
    save_keys(data)
