'''
map_layout = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]
'''
import pygame
import math
import random, json

# Initialize Pygame
pygame.init()

# Set screen dimensions
# WIDTH, HEIGHT = 600, 600
import pygame
import math
import random, json

# Initialize Pygame
pygame.init()

# Set screen dimensions
# WIDTH, HEIGHT = 600, 600
WIDTH, HEIGHT = 800, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bullet Echo-like Game")
FPS = 60

# Define Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (50, 50, 50)

def load_map():
    with open('map.json', 'r') as f:
        maps = json.load(f)
    return maps

def save_map(save):
    with open('map.json', 'w') as f:
        f.write(json.dumps(save))

map_layout = load_map()
TILES_WIDE = len(map_layout[0])
TILE_SIZE = WIDTH / TILES_WIDE



# Draw the map
def draw_map():
    for y, row in enumerate(map_layout):
        for x, tile in enumerate(row):
            if tile == 1:
                pygame.draw.rect(screen, GRAY, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))

def main(map_layout):
    y = 0
    x = 0

    running = True
    while running:
        screen.fill(BLACK)
        draw_map()
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Movement
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and y>0:
            y-=1
        if keys[pygame.K_s] and y<16:
            y+=1
        if keys[pygame.K_a] and x>0:
            x-=1
        if keys[pygame.K_d] and x<16:
            x+=1
        if keys[pygame.K_1]:
            map_layout[y][x] = 1
        if keys[pygame.K_0]:
            map_layout[y][x] = 0
        if keys[pygame.K_m]:
            save_map(map_layout)
            map_layout = load_map()

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main(map_layout=map_layout)
FPS = 60

# Define Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (50, 50, 50)

def load_map():
    with open('map.json', 'r') as f:
        maps = json.load(f)
    return maps

def save_map(save):
    with open('map.json', 'w') as f:
        f.write(json.dumps(save))

map_layout = load_map()
TILES_WIDE = len(map_layout[0])
TILE_SIZE = WIDTH / TILES_WIDE



# Draw the map
def draw_map():
    for y, row in enumerate(map_layout):
        for x, tile in enumerate(row):
            if tile == 1:
                pygame.draw.rect(screen, GRAY, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))

def main(map_layout):
    y = 0
    x = 0

    running = True
    while running:
        screen.fill(BLACK)
        draw_map()
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Movement
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and y>0:
            y-=1
        if keys[pygame.K_s] and y<16:
            y+=1
        if keys[pygame.K_a] and x>0:
            x-=1
        if keys[pygame.K_d] and x<16:
            x+=1
        if keys[pygame.K_1]:
            map_layout[y][x] = 1
        if keys[pygame.K_0]:
            map_layout[y][x] = 0
        if keys[pygame.K_m]:
            save_map(map_layout)
            map_layout = load_map()

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main(map_layout=map_layout)