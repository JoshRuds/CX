import random

def generate_connected_map(width, height):
    # Initialize the grid with all 1s (walls)
    map_grid = [[1 for _ in range(width)] for _ in range(height)]
    
    # List of directions for path carving: right, left, down, up
    directions = [(0, 2), (0, -2), (2, 0), (-2, 0)]
    
    def is_in_bounds(x, y):
        return 2 <= x < width - 2 and 2 <= y < height - 2
    
    def generate_path(x, y):
        # Stack for depth-first path generation
        stack = [(x, y)]
        map_grid[y][x] = 0  # Starting point is a zero
        map_grid[y+1][x] = 0  # Make the path two cells wide vertically
        map_grid[y][x+1] = 0  # Make the path two cells wide horizontally
        
        while stack:
            current_x, current_y = stack.pop()
            
            # Shuffle directions to ensure randomness
            random.shuffle(directions)
            
            for dx, dy in directions:
                nx, ny = current_x + dx, current_y + dy
                between_x, between_y = current_x + dx // 2, current_y + dy // 2
                
                if is_in_bounds(nx, ny) and map_grid[ny][nx] == 1:
                    # Carve out a two-cell wide path
                    map_grid[ny][nx] = 0
                    map_grid[ny + 1 if dy != 0 else ny][nx + 1 if dx != 0 else nx] = 0
                    map_grid[between_y][between_x] = 0  # Clear the space between
                    stack.append((nx, ny))
    
    # Start generating path from a random interior point
    start_x, start_y = random.randint(2, width - 3), random.randint(2, height - 3)
    generate_path(start_x, start_y)

    return map_grid

def print_map(map_grid):
    for row in map_grid:
        print(row)

# Example usage
width = 16
height = 16
map_grid = generate_connected_map(width, height)
print(map_grid)
