import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up the display
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Pause Menu Example")

# Set up font
font = pygame.font.Font(None, 74)
small_font = pygame.font.Font(None, 36)

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Game state variables
paused = False

# Function to display the pause menu
def display_pause_menu():
    screen.fill(BLACK)

    # Display "Paused" text
    paused_text = font.render("Paused", True, WHITE)
    screen.blit(paused_text, (screen_width // 2 - paused_text.get_width() // 2, screen_height // 2 - 100))

    # Display "Press P to resume"
    resume_text = small_font.render("Press P to resume", True, WHITE)
    screen.blit(resume_text, (screen_width // 2 - resume_text.get_width() // 2, screen_height // 2))

    # Display "Press Q to quit"
    quit_text = small_font.render("Press Q to quit", True, WHITE)
    screen.blit(quit_text, (screen_width // 2 - quit_text.get_width() // 2, screen_height // 2 + 50))

    pygame.display.flip()

# Main game loop
def game_loop():
    global paused

    clock = pygame.time.Clock()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    paused = not paused  # Toggle pause state

                if event.key == pygame.K_q and paused:
                    pygame.quit()
                    sys.exit()

        if paused:
            display_pause_menu()
        else:
            # Fill the screen with white while the game is running
            screen.fill(WHITE)

            # Display some "game" content
            game_text = font.render("Game Running", True, BLACK)
            screen.blit(game_text, (screen_width // 2 - game_text.get_width() // 2, screen_height // 2 - game_text.get_height() // 2))

            pygame.display.flip()

        # Cap the frame rate
        clock.tick(60)

# Run the game loop
if __name__ == "__main__":
    game_loop()
