import tkinter as tk
from tkinter import ttk
import json
import os
import pygame
pygame.init()
with open('keys.json', 'r') as file:
    keybinds = dict(json.loads(file.read()))

# Update keybind based on dropdown selection
def update_keybind(key, value):
    val_index = values.index(str(value))
    object_to_set = set_to[val_index]
    if object_to_set == 'N/A':
        return
    with open('keys.json', 'w') as file:
        keybinds[key] = object_to_set
        json.dump(keybinds, file)
    return



# Create the main application window
root = tk.Tk()
root.title("Keybind Editor")

# Load existing keybinds
all_binds=list(keybinds.keys())
values=["Keep Same", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'LShift', 'Caps', 'Ctrl', 'Space', 'Up Arrow', 'Left Arrow', 'Down Arrow', 'Right Arrow']
set_to = ['N/A',97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,49,50,51,52,53,54,55,56,57,48,1073742049,1073741881,1073742048,32,1073741906,1073741904,1073741905,1073741903,]
# Create dropdowns for each keybind
for key in all_binds:
    i = all_binds.index(key)
    label = tk.Label(root, text=key)
    label.grid(row=i, column=0)

    dropdown = ttk.Combobox(root, values=values)
    dropdown.set(keybinds[key])
    dropdown.grid(row=i, column=1)
    dropdown.bind("<<ComboboxSelected>>", lambda event, k=key: update_keybind(k, dropdown.get()))

# Start the GUI event loop
root.mainloop()
