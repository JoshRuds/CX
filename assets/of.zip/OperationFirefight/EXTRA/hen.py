import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
import time
import random

# Screen dimensions
WIDTH, HEIGHT = 800, 600

# Colors
GREEN = (0, 1, 0)
RED = (1, 0, 0)
BLUE = (0, 0, 1)
YELLOW = (1, 1, 0)

# Player settings
player_pos = [0, 0, 0]
player_speed = 0.2
player_size = 1

# Game state
running = True
enemies = []  # List of enemies
bullets = []  # List of bullets

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT), DOUBLEBUF | OPENGL)
pygame.display.set_caption("3D Top-Down Shooter with Leg Shot Mechanic")
clock = pygame.time.Clock()

# Set up OpenGL perspective
glMatrixMode(GL_PROJECTION)
gluPerspective(45, (WIDTH / HEIGHT), 0.1, 50.0)
glTranslatef(0.0, -5.0, -20)
glRotatef(45, 1, 0, 0)

# Enemy class
class Enemy:
    def _init_(self, position, size):
        self.position = position  # [x, y, z]
        self.size = size  # Size of the enemy
        self.is_staggered = False  # Is the enemy currently staggered?
        self.stagger_end_time = 0  # When does the stagger end?

    def check_stagger(self, current_time):
        """Check if the enemy should stop being staggered."""
        if self.is_staggered and current_time >= self.stagger_end_time:
            self.is_staggered = False

    def take_damage(self, hit_location):
        """Handle taking damage."""
        if hit_location == "leg":
            self.is_staggered = True
            self.stagger_end_time = time.time() + 3  # Stagger for 3 seconds

    def render(self):
        """Render the enemy."""
        glPushMatrix()
        glTranslatef(*self.position)
        if self.is_staggered:
            glColor3f(*RED)  # Red when staggered
        else:
            glColor3f(*GREEN)  # Green when normal
        glutSolidCube(self.size)
        glPopMatrix()

# Bullet class
class Bullet:
    def _init_(self, position, direction):
        self.position = position[:]
        self.direction = direction
        self.speed = 0.5

    def move(self):
        """Move the bullet."""
        self.position[0] += self.direction[0] * self.speed
        self.position[2] += self.direction[2] * self.speed

    def render(self):
        """Render the bullet."""
        glPushMatrix()
        glTranslatef(*self.position)
        glColor3f(*YELLOW)  # Yellow bullet
        glutSolidSphere(0.2, 10, 10)
        glPopMatrix()

# Initialize enemies
for _ in range(5):
    x = random.uniform(-10, 10)
    z = random.uniform(-10, -5)
    enemies.append(Enemy([x, 0, z], 1))

# Define the player's shooting function
def shoot_bullet():
    """Simulate shooting a bullet."""
    global bullets
    bullets.append(Bullet(player_pos, [0, 0, -1]))  # Simplified forward shooting

# Main game loop
while running:
    current_time = time.time()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Shooting logic
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            shoot_bullet()

    # Player movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        player_pos[2] -= player_speed
    if keys[pygame.K_s]:
        player_pos[2] += player_speed
    if keys[pygame.K_a]:
        player_pos[0] -= player_speed
    if keys[pygame.K_d]:
        player_pos[0] += player_speed

    # Update bullets
    for bullet in bullets:
        bullet.move()
        # Check for collisions with enemies
        for enemy in enemies:
            dx = abs(bullet.position[0] - enemy.position[0])
            dz = abs(bullet.position[2] - enemy.position[2])
            if dx < 1 and dz < 1:
                # Randomly determine if it's a leg shot
                hit_location = "leg" if random.random() < 0.5 else "body"
                enemy.take_damage(hit_location)
                bullets.remove(bullet)
                break

    # Update enemies
    for enemy in enemies:
        enemy.check_stagger(current_time)

    # Rendering
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    # Render player
    glPushMatrix()
    glTranslatef(*player_pos)
    glColor3f(*BLUE)  # Blue player
    glutSolidCube(player_size)
    glPopMatrix()

    # Render bullets
    for bullet in bullets:
        bullet.render()

    # Render enemies
    for enemy in enemies:
        enemy.render()

    pygame.display.flip()
    clock.tick(60)

pygame.quit()