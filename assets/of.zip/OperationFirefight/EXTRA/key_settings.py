import tkinter as tk
import json

def save_keys(data):
    with open('keys_save.json', 'w') as f:
        f.write(json.dumps(data))

def load_keys():
    with open('keys_save.json', 'r') as f:
        data = f.read()
    data = json.loads(data)
    return data

class KeyPressApp:
    def __init__(self, master, data):
        self.data = data
        self.master = master
        self.master.title("Key Press Tracker")
        
        self.label = tk.Label(master, text="Press the key for {}")
        self.label.pack(pady=20)

        self.key_pressed = tk.StringVar()
        self.key_display = tk.Label(master, textvariable=self.key_pressed)
        self.key_display.pack(pady=20)

        self.set_button = tk.Button(master, text="Set Key", command=self.set_key)
        self.set_button.pack(pady=20)

        self.master.bind("<Key>", self.on_key_press)

    def on_key_press(self, event):
        self.key_pressed.set(f"Key Pressed: {event.keysym}")

    def set_key(self):

        current_key = self.key_pressed.get().replace("Key Pressed: ", "")
        print(f"Key set to: {current_key}")
        #self.data[]

if __name__ == "__main__":
    root = tk.Tk()
    data = load_keys()
    app = KeyPressApp(root,data)
    root.mainloop()