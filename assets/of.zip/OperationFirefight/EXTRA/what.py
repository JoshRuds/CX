import pygame
import random
import math

# Initialize pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Top-Down Shooter")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

# Clock for controlling the frame rate
clock = pygame.time.Clock()

# Player settings
player_size = 50
player_x = WIDTH // 2
player_y = HEIGHT // 2
player_speed = 5
player_health = 100

# Bullet settings
bullets = []
bullet_speed = 10

# Enemy settings
enemies = []
enemy_size = 50
enemy_speed = 2
enemy_spawn_time = 1000  # in milliseconds
last_enemy_spawn = pygame.time.get_ticks()

# Power-up settings
power_ups = []
power_up_size = 30
power_up_spawn_time = 8000  # in milliseconds
last_power_up_spawn = pygame.time.get_ticks()

# Player score
score = 0

# Font for score display and game over
font = pygame.font.Font(None, 36)
game_over_font = pygame.font.Font(None, 72)

# Functions to draw elements
def draw_player(x, y):
    pygame.draw.rect(screen, GREEN, (x, y, player_size, player_size))

def draw_bullets():
    for bullet in bullets:
        pygame.draw.circle(screen, RED, (bullet[0], bullet[1]), 5)

def draw_enemies():
    for enemy in enemies:
        pygame.draw.rect(screen, WHITE, (enemy[0], enemy[1], enemy_size, enemy_size))

def draw_power_ups():
    for power_up in power_ups:
        pygame.draw.rect(screen, BLUE, (power_up[0], power_up[1], power_up_size, power_up_size))

def game_over():
    text = game_over_font.render("GAME OVER", True, RED)
    screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 - text.get_height() // 2))
    pygame.display.flip()
    pygame.time.delay(3000)
    pygame.quit()
    exit()

# Main game loop
running = True
while running:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Player movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]: player_y -= player_speed
    if keys[pygame.K_s]: player_y += player_speed
    if keys[pygame.K_a]: player_x -= player_speed
    if keys[pygame.K_d]: player_x += player_speed

    # Shooting toward mouse
    mouse_x, mouse_y = pygame.mouse.get_pos()
    if pygame.mouse.get_pressed()[0]:  # Left mouse button
        angle = math.atan2(mouse_y - (player_y + player_size // 2), mouse_x - (player_x + player_size // 2))
        bullets.append([player_x + player_size // 2, player_y + player_size // 2, angle])

    # Move bullets
    for bullet in bullets:
        bullet[0] += bullet_speed * math.cos(bullet[2])
        bullet[1] += bullet_speed * math.sin(bullet[2])
    bullets = [bullet for bullet in bullets if 0 < bullet[0] < WIDTH and 0 < bullet[1] < HEIGHT]

    # Spawn enemies
    if pygame.time.get_ticks() - last_enemy_spawn > enemy_spawn_time:
        enemies.append([random.randint(0, WIDTH - enemy_size), -enemy_size])
        last_enemy_spawn = pygame.time.get_ticks()

    # Move enemies
    for enemy in enemies:
        # Move toward the player
        dx = player_x - enemy[0]
        dy = player_y - enemy[1]
        dist = math.sqrt(dx**2 + dy**2)
        if dist != 0:
            enemy[0] += enemy_speed * dx / dist
            enemy[1] += enemy_speed * dy / dist

    # Spawn power-ups
    if pygame.time.get_ticks() - last_power_up_spawn > power_up_spawn_time:
        power_ups.append([random.randint(0, WIDTH - power_up_size), random.randint(0, HEIGHT - power_up_size)])
        last_power_up_spawn = pygame.time.get_ticks()

    # Check collisions: bullets and enemies
    for bullet in bullets:
        for enemy in enemies:
            if (
                enemy[0] < bullet[0] < enemy[0] + enemy_size and
                enemy[1] < bullet[1] < enemy[1] + enemy_size
            ):
                bullets.remove(bullet)
                enemies.remove(enemy)
                score += 1
                break

    # Check collisions: player and enemies
    for enemy in enemies:
        if (
            player_x < enemy[0] + enemy_size and
            player_x + player_size > enemy[0] and
            player_y < enemy[1] + enemy_size and
            player_y + player_size > enemy[1]
        ):
            enemies.remove(enemy)
            player_health -= 20
            if player_health <= 0:
                game_over()

    # Check collisions: player and power-ups
    for power_up in power_ups:
        if (
            player_x < power_up[0] + power_up_size and
            player_x + player_size > power_up[0] and
            player_y < power_up[1] + power_up_size and
            player_y + player_size > power_up[1]
        ):
            power_ups.remove(power_up)
            player_health = min(player_health + 20, 100)

    # Remove off-screen enemies
    enemies = [enemy for enemy in enemies if 0 < enemy[0] < WIDTH and 0 < enemy[1] < HEIGHT]

    # Draw everything
    draw_player(player_x, player_y)
    draw_bullets()
    draw_enemies()
    draw_power_ups()

    # Draw health bar
    pygame.draw.rect(screen, RED, (10, 10, 200, 20))
    pygame.draw.rect(screen, GREEN, (10, 10, 2 * player_health, 20))

    # Draw score
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 40))

    # Update the screen
    pygame.display.flip()

    # Control the frame rate
    clock.tick(60)

pygame.quit()
