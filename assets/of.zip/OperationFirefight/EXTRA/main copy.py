import pygame
import math
import random
import os
import data.home_screen as home_screen
import time
from data.guns import *
from data.settings import *
from launcher import launcher
from edit_keys import edit_keys
from data.mission_selector import draw_mission_selection_screen, nato_alphabet

# Initialize Pygame
pygame.init()
pygame.font.init()
pygame.mixer.init()

while True:
    result = launcher()
    if result == None:
        pygame.quit()
        quit()
    elif result == False:
        edit_keys()
        continue
    elif result == True:
        break

# Set screen dimensions
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption(TITLE)

# Game clock
clock = pygame.time.Clock()

death_ani = []
for i in range(60):
    exec(f'death_ani.append(pygame.image.load(os.path.join("assets", "game_over", "image00001-{i}.png")).convert())')

shop_ani = []
for i in range(15):
    exec(f'shop_ani.append(pygame.image.load(os.path.join("assets", "shop_scrn", "shop-{i}.png")).convert())')

gold_coin = pygame.image.load(os.path.join('assets', 'gold_coin.png')).convert()
gold_coin = pygame.transform.scale(gold_coin, COIN_SIZE)
silver_coin = pygame.image.load(os.path.join('assets', 'silver_coin.png')).convert()
silver_coin = pygame.transform.scale(silver_coin, COIN_SIZE)
bronze_coin = pygame.image.load(os.path.join('assets', 'bronze_coin.png')).convert()
bronze_coin = pygame.transform.scale(bronze_coin, COIN_SIZE)

target_cursor = pygame.image.load(os.path.join('assets', 'cursor.png')).convert_alpha()
target_cursor = pygame.transform.scale(target_cursor, (32,32))
#map_layout = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1], [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1], [1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1], [1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]

TILES_WIDE = len(map_layout[0])
TILE_SIZE = WIDTH / TILES_WIDE
# TILE_SIZE = 150

GOLD = 0
SILVER = 0
BRONZE = 0

def play(sound):
    pygame.mixer.Sound.play(sound)
# Player class
class Player:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.angle = 0
        self.bullets_remaining = GUNS.GLOCK.CLIP
    
    def dash(self):
        rad = math.radians(self.get_mouse_angle())
        dx = math.cos(rad)
        dy = math.sin(rad)
        self.move(dx,dy,100)

    def move(self, dx, dy, speed = player_speed):
        new_x = self.x + dx * speed
        new_y = self.y + dy * speed

        # Check for wall collisions
        if not self.collides_with_wall(new_x, self.y):
            self.x = new_x
        if not self.collides_with_wall(self.x, new_y):
            self.y = new_y

    def collides_with_wall(self, x, y):
        grid_x = int(x // TILE_SIZE)
        grid_y = int(y // TILE_SIZE)
        return map_layout[grid_y][grid_x] == 1

    def draw(self):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), player_size)

        # Fog of war
        pygame.draw.circle(screen, COLOURS.BLACK, (int(self.x), int(self.y)), fov_radius, 1)
    
    def get_mouse_angle(self):
        mouse_x = pygame.mouse.get_pos()[0]
        mouse_y = pygame.mouse.get_pos()[1]
        angle = math.atan2(mouse_y - self.y, mouse_x - self.x)
        angle = angle * (180 / math.pi)
        return angle

    def shoot(self, shotgun: bool, max_offset: int):
        self.bullets_remaining -= 1
        if shotgun:
            for i in range(11):
                rad = math.radians(self.get_mouse_angle() + 1*(i-5))
                dx = math.cos(rad) * bullet_speed
                dy = math.sin(rad) * bullet_speed
                bullets.append(Bullet(self.x, self.y, dx, dy, self.color))
        else:
            if random.choice([True,False]):
                rad = math.radians(self.get_mouse_angle() + random.randint(0,max_offset))
            else:
                rad = math.radians(self.get_mouse_angle() - random.randint(0,max_offset))
            dx = math.cos(rad) * bullet_speed
            dy = math.sin(rad) * bullet_speed
            bullets.append(Bullet(self.x, self.y, dx, dy, self.color))
    
    def get_bullets_remaining(self):
        return self.bullets_remaining
    
    def set_bullets_remaining(self, to: int):
        self.bullets_remaining = to

# Bullet class
class Bullet:
    def __init__(self, x, y, dx, dy, color):
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
        self.color = color
        

    def update(self):
        self.x += self.dx
        self.y += self.dy

    def collides_with_wall(self, x, y):
        grid_x = int(x // TILE_SIZE)
        grid_y = int(y // TILE_SIZE)
        return map_layout[grid_y][grid_x] == 1

    def draw(self):
        #body = pygame.Rect(self.x, self.y, 20, 30)
        #body = pygame.transform.rotate(body, self.get_mouse_angle())
        pygame.draw.circle(screen, self.color, (self.x, self.y), 5)

    def get_mouse_angle(self):
        mouse_x = pygame.mouse.get_pos()[0]
        mouse_y = pygame.mouse.get_pos()[1]
        angle = math.atan2(mouse_y - self.y, mouse_x - self.x)
        angle = angle * (180 / math.pi)
        return angle

    def is_out_of_bounds(self):
        return not (0 <= self.x <= WIDTH and 0 <= self.y <= HEIGHT)

# Draw the map
def draw_map():
    for y, row in enumerate(map_layout):
        for x, tile in enumerate(row):
            if tile == 1:
                pygame.draw.rect(screen, COLOURS.GRAY, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))


# Setup Font
font = pygame.font.Font('freesansbold.ttf', 74)
shop_font = pygame.font.Font('freesansbold.ttf', 52)
small_font = pygame.font.Font('freesansbold.ttf', 36)

def empty_text():
    # Print Gun Name to screen
    printable = 'EMPTY'
    text = font.render(printable, True, COLOURS.RED)
    textRect = text.get_rect()
    textRect.center = (WIDTH//2, HEIGHT//2)
    screen.blit(text, textRect)

# Define the pause menu
def display_pause_menu():
    screen.fill(COLOURS.BLACK)

    # Display "Paused" text
    paused_text = font.render("Paused", True, COLOURS.WHITE)
    screen.blit(paused_text, (WIDTH // 2 - paused_text.get_width() // 2, HEIGHT // 2 - 100))

    # Display "Press P to resume"
    resume_text = small_font.render("Press P to resume", True, COLOURS.WHITE)
    screen.blit(resume_text, (WIDTH // 2 - resume_text.get_width() // 2, HEIGHT // 2))

    # Display "Press Q to quit"
    quit_text = small_font.render("Press Q to quit", True, COLOURS.WHITE)
    screen.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT // 2 + 50))

def game_over():
    for img in death_ani:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                break
        bg = pygame.transform.scale(img, (WIDTH, HEIGHT))
        screen.blit(bg, (0,0))
        pygame.display.flip()
        clock.tick(10)
    time.sleep(5)
    
def shop():
    while True:
        for img in shop_ani:
            bg = pygame.transform.scale(img, (WIDTH, HEIGHT))
            screen.blit(bg, (0,0))
            screen.blit(gold_coin, (0, HEIGHT-52))
            screen.blit(silver_coin, (0, HEIGHT-114))
            screen.blit(bronze_coin, (0, HEIGHT-176))

            printable = str(GOLD)
            text = shop_font.render(printable, True, COLOURS.RED)
            textRect = text.get_rect()
            textRect.topleft = (60,HEIGHT-52)
            screen.blit(text, textRect)
            printable = str(SILVER)
            text = shop_font.render(printable, True, COLOURS.RED)
            textRect = text.get_rect()
            textRect.topleft = (60,HEIGHT-114)
            screen.blit(text, textRect)
            printable = str(BRONZE)
            text = shop_font.render(printable, True, COLOURS.RED)
            textRect = text.get_rect()
            textRect.topleft = (60,HEIGHT-176)
            screen.blit(text, textRect)
            pygame.display.flip()
            clock.tick(8)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        return True


# Main game loop
def main(letter:str):
    pygame.cursors.Cursor(pygame.SYSTEM_CURSOR_CROSSHAIR)
    
    player = Player(WIDTH // 2, HEIGHT // 2, COLOURS.BLUE)
    while player.collides_with_wall(player.x,player.y):
        player.y-=5
    cooldown = 0
    dash_cool = 0
    empty = 0
    safe = False
    gun = GUNS.GLOCK
    shooting = False
    paused = False
    RELOAD = pygame.mixer.Sound(os.path.join('sound', 'RELOAD.mp3'))
    pygame.mouse.set_visible(False)


    running = True
    while running:
        searching = False
        reloading = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_0:
                    safe = True  # Toggle pause state
                if event.key == pygame.K_DELETE:
                    game_over()
                    pygame.quit()
                    quit()
                if event.key == pygame.K_ESCAPE:
                    printable = f'Name: {gun.NAME}\nShotgun: {gun.SHOTGUN}'
                    text = small_font.render(printable, True, COLOURS.RED)
                    textRect = text.get_rect()
                    textRect.center = ((WIDTH//2, HEIGHT//2))
                    screen.blit(text, textRect)
            
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  
                shooting = True
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:  
                reloading = True
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                shooting = False
                #Left Click (SHOOT)
        if shooting and cooldown == 0:
            if bullets_left > 0:
                player.shoot(gun.SHOTGUN, gun.MAX_OFFSET)
                cooldown = math.floor(FPS / gun.MAX_SHOTS_A_SECOND)
                play(gun.SOUND)
            else:
                empty = 30
                play(pygame.mixer.Sound(os.path.join('sound', 'EMPTY.mp3')))

        #Right Click (RELOAD)
        if reloading:
            player.set_bullets_remaining(gun.CLIP)
            cooldown = math.floor(FPS * gun.RELOAD)
        
        if searching:
            printable = f'Name: {gun.NAME}\nShotgun: {gun.SHOTGUN}'
            text = small_font.render(printable, True, COLOURS.RED)
            textRect = text.get_rect()
            textRect.center = ((WIDTH//2, HEIGHT//2))
            screen.blit(text, textRect)
        
                    
        screen.fill(COLOURS.BLACK)
        draw_map()
        
        # Print Bullets Remaining to screen
        bullets_left = player.get_bullets_remaining()
        printable = str(bullets_left)
        text = small_font.render(printable, True, COLOURS.RED)
        textRect = text.get_rect()
        textRect.topright = (WIDTH, 0)
        screen.blit(text, textRect)

        # Print Cooldown to screen
        printable = str(cooldown).removesuffix('.0')
        text = small_font.render(printable, True, COLOURS.RED)
        textRect = text.get_rect()
        textRect.topleft = (0, 0)
        screen.blit(text, textRect)

        printable = ('Operation ' + nato_alphabet[letter]).upper()
        text = small_font.render(printable, True, COLOURS.RED)
        textRect = text.get_rect()
        textRect.bottomleft = (0, HEIGHT)
        screen.blit(text, textRect)

        screen.blit(target_cursor, pygame.mouse.get_pos())
        

        # Print Gun Name to screen
        if safe:
            printable = gun.SAFE
        else:
            printable = gun.NAME
        text = small_font.render(printable, True, COLOURS.RED)
        textRect = text.get_rect()
        textRect.bottomright = (WIDTH, HEIGHT)
        screen.blit(text, textRect)

        # Movement
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            player.move(0, -1)
        if keys[pygame.K_s]:
            player.move(0, 1)
        if keys[pygame.K_a]:
            player.move(-1, 0)
        if keys[pygame.K_d]:
            player.move(1, 0)
        if keys[pygame.K_SPACE]:
            if dash_cool == 0:
                player.dash()
                dash_cool = FPS*10 #10 sec
        if keys[pygame.K_2]:
            gun = GUNS.GLOCK
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[pygame.K_3]:
            gun = GUNS.AK47
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[pygame.K_5]:
            gun = GUNS.EAGLEPOINT
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[pygame.K_6]:
            gun = GUNS.SCAR
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[pygame.K_7]:
            gun = GUNS.M4A1
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[pygame.K_8]:
            gun = GUNS.REMINGTON
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[pygame.K_4]:
            gun = GUNS.BROWNING
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[pygame.K_1]:
            gun = GUNS.REVOLVER
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)

        # Bullet update
        for bullet in bullets[:]:
            bullet.update()
            if bullet.is_out_of_bounds() or bullet.collides_with_wall(bullet.x, bullet.y):
                bullets.remove(bullet)

        # Draw bullets
        for bullet in bullets:
            bullet.draw()

        # Draw player
        player.draw()
        if cooldown > 0:
            cooldown -= 1
        if dash_cool > 0:
            dash_cool -= 1
        if empty > 0:
            empty_text()
            empty -= 1
        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()

if __name__ == "__main__":
    bg_path = os.path.join('assets', 'home_scrn.jpg')
    bg = pygame.image.load(bg_path)
    bg = pygame.transform.scale(bg, (WIDTH, HEIGHT))
    screen.blit(bg, (0,0))
    pygame.display.flip()
    time.sleep(3)
    while True:
        if not home_screen.show_home():
            if shop():
                continue
        else: 
            result_mission = draw_mission_selection_screen()
            main(result_mission)