import random

def generate_random_map(width, height):
    game_map = [[1] * width for _ in range(height)]
    
    for y in range(1, height - 1):
        for x in range(1, width - 1):
            game_map[y][x] = random.choice([0, 1])
    
    return game_map

def print_map(game_map):
    for row in game_map:
        print(row)

width = 16
height = 16
random_map = generate_random_map(width, height)
print_map(random_map)