import pygame
import math

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
PLAYER_RADIUS = 15
ENEMY_RADIUS = 10
WALL_COLOR = (128, 128, 128)
ENEMY_COLOR = (255, 165, 0)
PLAYER_COLOR = (0, 0, 255)

# Setup the display
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Enemy Visibility")

# Player and enemy positions
player_pos = (100, 300)
enemy_pos = (700, 300)
wall_pos = (400, 0, 20, HEIGHT)  # Wall at x=400

def is_visible(player_pos, enemy_pos, wall_pos):
    # Check if the wall is between the player and the enemy
    wall_rect = pygame.Rect(wall_pos)
    line = pygame.draw.line(screen, (0, 0, 0), player_pos, enemy_pos, 0)
    return not line.colliderect(wall_rect)

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((255, 255, 255))  # Clear screen

    # Draw wall
    pygame.draw.rect(screen, WALL_COLOR, wall_pos)

    # Draw player
    pygame.draw.circle(screen, PLAYER_COLOR, player_pos, PLAYER_RADIUS)

    # Check visibility and draw enemy
    if is_visible(player_pos, enemy_pos, wall_pos):
        pygame.draw.circle(screen, ENEMY_COLOR, enemy_pos, ENEMY_RADIUS)

    pygame.display.flip()

pygame.quit()
