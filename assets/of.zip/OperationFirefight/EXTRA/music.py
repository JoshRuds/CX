import pygame
import time

# Initialize Pygame mixer
pygame.mixer.init()

# Load the MP3 file
pygame.mixer.music.load("footsteps.mp3")

# Function to play the sound
def play_sound():
    pygame.mixer.music.play(-1)  # -1 means loop indefinitely

# Function to pause the sound
def pause_sound():
    pygame.mixer.music.pause()

# Function to unpause the sound
def unpause_sound():
    pygame.mixer.music.unpause()

# Main loop
if __name__ == "__main__":
    play_sound()
    try:
        while True:
            command = input("Enter 'pause' to pause, 'unpause' to unpause, or 'exit' to quit: ").strip().lower()
            if command == 'pause':
                pause_sound()
            elif command == 'unpause':
                unpause_sound()
            elif command == 'exit':
                pygame.mixer.music.stop()
                break
            else:
                print("Invalid command. Please try again.")
    except KeyboardInterrupt:
        pygame.mixer.music.stop()