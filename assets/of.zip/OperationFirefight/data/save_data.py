from cryptography.fernet import Fernet

# key generation
key = Fernet.generate_key()
 
def load(section):

   # using the key
   fernet = Fernet(key)

   with open('save_data.dat', 'rb') as f:
      encrypted = f.read()
   
   # decrypting the file
   decrypted = fernet.decrypt(encrypted)

   return decrypted.decode().split('!!!!!')[section]

def save(data):
         
   # using the key
   fernet = Fernet(key)
   # opening the file in write mode and
   # writing the decrypted data
   with open('save_data.dat', 'wb') as dec_file:
      dec_file.write(fernet.encrypt(bytes(data)))
   
save(b'''A:T
B:F
C:F
D:F
E:F
F:F
G:F
H:F
I:F
J:F
K:F
L:F
M:F
N:F
O:F
P:F
Q:F
R:F
S:F
T:F
U:F
V:F
W:F
X:F
Y:F
Z:F
!!!!!
{"Up": 119, "Down": 115, "Left": 97, "Right": 100, "Suicide": 1073742048, "Revolver": 49, "Glock": 50, "Ak47": 51, "Browning": 52, "Eaglepoint": 53, "M4A1": 54, "Remington": 55, "Scar": 56, "Dash": 32}
''')
