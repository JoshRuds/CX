import pygame, os
pygame.mixer.init()
# Guns and Facts
class GUNS:
    
    class REVOLVER:
        CLIP = 6
        MAX_SHOTS_A_SECOND = 1
        RELOAD = 2
        SOUND = pygame.mixer.Sound(os.path.join('sound', 'GLOCK.mp3'))
        NAME = 'REVOLVER'
        SAFE = 'PISTOL'
        SHOTGUN = False
        MAX_OFFSET = 1
    class GLOCK:
        CLIP = 7
        MAX_SHOTS_A_SECOND = 2
        RELOAD = 2
        SOUND = pygame.mixer.Sound(os.path.join('sound', 'GLOCK.mp3'))
        NAME = 'GLOCK'
        SAFE = 'PISTOL'
        SHOTGUN = False
        MAX_OFFSET = 2

    class AK47:
        CLIP = 30
        MAX_SHOTS_A_SECOND = 12
        RELOAD = 5
        SOUND = pygame.mixer.Sound(os.path.join('sound', 'AK47.mp3'))
        NAME = 'AK47'
        SAFE = 'SUB-MACHINE GUN'
        SHOTGUN = False
        MAX_OFFSET = 5

    class BROWNING:
        CLIP = 5
        MAX_SHOTS_A_SECOND = 0.5
        RELOAD = 3.5
        SOUND = pygame.mixer.Sound(os.path.join('sound', 'SHOTGUN.mp3'))
        NAME = 'BROWNING'
        SAFE = 'SHOTGUN'
        SHOTGUN = True
        MAX_OFFSET = 0  # Is shotgun has none

    class EAGLEPOINT:
        CLIP = 3
        MAX_SHOTS_A_SECOND = 0.2
        RELOAD = 7
        SOUND = pygame.mixer.Sound(os.path.join('sound', 'SNIPER.mp3'))
        NAME = 'EAGLEPOINT'
        SAFE = 'SNIPER'
        SHOTGUN = False
        MAX_OFFSET = 0

    class M4A1:
        CLIP = 30
        MAX_SHOTS_A_SECOND = 10
        RELOAD = 3
        SOUND = pygame.mixer.Sound(os.path.join('sound', 'M4A1.mp3'))
        NAME = 'M4A1'
        SAFE = 'ASSAULT RIFLE'
        SHOTGUN = False
        MAX_OFFSET = 4

    class REMINGTON:
        CLIP = 5
        MAX_SHOTS_A_SECOND = 1
        RELOAD = 2.5
        SOUND = pygame.mixer.Sound(os.path.join('sound', 'REMINGTON.mp3'))
        NAME = 'REMINGTON'
        SAFE = 'SHOTGUN'
        SHOTGUN = True
        MAX_OFFSET = 0

    class SCAR:
        CLIP = 20
        MAX_SHOTS_A_SECOND = 6
        RELOAD = 2
        SOUND = pygame.mixer.Sound(os.path.join('sound', 'SCAR.mp3'))
        NAME = 'SCAR'
        SAFE = 'ASSAULT RIFLE'
        SHOTGUN = False
        MAX_OFFSET = 3
        
list_of_guns = [GUNS.AK47, GUNS.GLOCK, GUNS.BROWNING, GUNS.EAGLEPOINT, GUNS.M4A1, GUNS.REMINGTON, GUNS.REVOLVER, GUNS.SCAR]

