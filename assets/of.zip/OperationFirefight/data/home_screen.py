def go(pygame,sys,os):
    WIDTH, HEIGHT = 800,800

    # Initialize Pygame
    pygame.init()

    # Define colors
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    GREEN = (0, 255, 0)
    RED = (255, 0, 0)
    BLUE = (0, 0, 255)

    # Button class
    class Button:
        def __init__(self, text, x, y, width, height, color, hover_color):
            self.text = text
            self.rect = pygame.Rect(x, y, width, height)
            self.color = color
            self.hover_color = hover_color
            self.font = pygame.font.Font(None, 36)

        def draw(self, screen):
            mouse_pos = pygame.mouse.get_pos()
            if self.rect.collidepoint(mouse_pos):
                pygame.draw.rect(screen, self.hover_color, self.rect)
            else:
                pygame.draw.rect(screen, self.color, self.rect)
            
            text_surface = self.font.render(self.text, True, BLACK)
            screen.blit(text_surface, (self.rect.x + (self.rect.width - text_surface.get_width()) // 2,
                                        self.rect.y + (self.rect.height - text_surface.get_height()) // 2))

        def is_clicked(self):
            mouse_click = pygame.mouse.get_pressed()
            return mouse_click[0] and self.rect.collidepoint(pygame.mouse.get_pos())

    # Create buttons
    '''
    start_button = Button("Start", 300, 200, 200, 50, GREEN, (0, 200, 0))
    quit_button = Button("Quit", 300, 300, 200, 50, RED, (200, 0, 0))
    shop_button = Button("Shop", 300, 400, 200, 50, BLUE, (0, 0, 200))
    ''' 
    # Set up display
    width, height = 800, 800
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Home Screen")
    

    menu_1 = os.path.join('assets', 'menu-1.jpg')
    menu_1 = pygame.image.load(menu_1)
    menu_1 = pygame.transform.scale(menu_1, (WIDTH, HEIGHT))

    menu_2 = os.path.join('assets', 'menu-2.jpg')
    menu_2 = pygame.image.load(menu_2)
    menu_2 = pygame.transform.scale(menu_2, (WIDTH, HEIGHT))

    menu_3 = os.path.join('assets', 'menu-3.jpg')
    menu_3 = pygame.image.load(menu_3)
    menu_3 = pygame.transform.scale(menu_3, (WIDTH, HEIGHT))
    menu = menu_1
    i = 1
    # Main loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    i -= 1
                    if i < 1: i = 1

                if event.key == pygame.K_DOWN:
                    i += 1
                    if i > 3: i = 3
                
                if event.key == pygame.K_RETURN:
                    if menu == menu_1:
                        print("Game Started!")  # Placeholder for starting the game
                        return True
                    if menu == menu_2:
                        print("Displaying Shop")  # Placeholder for shop display
                        return False
                    if menu == menu_3:
                        pygame.quit()
                        quit()
                    
                
        
        menu = eval(f'menu_{i}')
        #screen.fill(WHITE)
        screen.blit(menu, (0,0))
        # Draw buttons
        '''
        start_button.draw(screen)
        quit_button.draw(screen)
        shop_button.draw(screen)'''

        # Check button clicks
        '''
        if #start_button.is_clicked():
            print("Game Started!")  # Placeholder for starting the game
            return True
        if #quit_button.is_clicked():
            pygame.quit()
            sys.exit()
        if #shop_button.is_clicked():
            print("Displaying Shop")  # Placeholder for shop display
            return False'''

        pygame.display.flip()