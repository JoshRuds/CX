def go(pygame,sys,os):
    import data.save_data as save_data

    # Constants
    SCREEN_WIDTH = 800
    SCREEN_HEIGHT = 800
    FONT_SIZE = 40
    BACKGROUND_COLOR = (30, 30, 30)
    TEXT_COLOR = (255, 255, 255)
    BLUE = (0,0,255)


    # NATO Phonetic Alphabet
    nato_alphabet = {
        'A': 'Alpha', 'B': 'Bravo', 'C': 'Charlie', 'D': 'Delta',
        'E': 'Echo', 'F': 'Foxtrot', 'G': 'Golf', 'H': 'Hotel',
        'I': 'India', 'J': 'Juliett', 'K': 'Kilo', 'L': 'Lima',
        'M': 'Mike', 'N': 'November', 'O': 'Oscar', 'P': 'Papa',
        'Q': 'Quebec', 'R': 'Romeo', 'S': 'Sierra', 'T': 'Tango',
        'U': 'Uniform', 'V': 'Victor', 'W': 'Whiskey', 'X': 'X-ray',
        'Y': 'Yankee', 'Z': 'Zulu'
    }
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Mission Selection")
    font = pygame.font.Font(None, FONT_SIZE)
    padlock = pygame.image.load(os.path.join('assets', 'padlock.png')).convert_alpha()
    padlock = pygame.transform.scale(padlock, (43,35))
    data = save_data.load(0).splitlines()
    for index, (letter, name) in enumerate(nato_alphabet.items()):
        exec(f'unlocked_{letter} = {True if data[index].split(':')[1] == 'T' else False}')
    # Main loop
    while True:
        screen.fill(BACKGROUND_COLOR)
    # Draw mission options
        y_offset = 50
        for index, (letter, name) in enumerate(nato_alphabet.items()):
            
            mission_text = f"Operation {name}"
            text_surface = font.render(mission_text, True, TEXT_COLOR)
            if index % 2 != 0: # odd
                even = True
                button_width = 300
                button_height = 40
                button_x = (SCREEN_WIDTH // 4 * 3) - 150
                button_y = y_offset - 20
                text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 4 * 3, y_offset))
                
            else: # even
                even = False
                button_width = 300
                button_height = 40
                button_x = (SCREEN_WIDTH // 4) - 150
                button_y = y_offset - 20
                text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 4, y_offset))
            
            exec(f'button_{letter} = pygame.draw.rect(screen,(99,99,99), (button_x, button_y, button_width, button_height),  border_radius=3)')
            screen.blit(text_surface, text_rect)
            if eval(f'unlocked_{letter} == False'): screen.blit(padlock, (button_x + button_width // 2 - 21.5, button_y, button_width, button_height))
            if even: y_offset += 50
        # Check for mouse click
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    mouse_x, mouse_y = event.pos
                    for index, (letter, name) in enumerate(nato_alphabet.items()):
                        if eval(f'button_{letter}.collidepoint(mouse_x, mouse_y)'):
                            if eval(f'unlocked_{letter}') == True:
                                return letter

        pygame.display.flip()
