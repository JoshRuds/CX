def edit_keys():
    import tkinter as tk
    from tkinter import ttk
    import json
    import pygame

    pygame.init()

    with open('keys.json', 'r') as file:
        keybinds = json.load(file)
    
    def save_keybind():
        for i, item in enumerate(dropdowns):
            key = all_binds[i]
            value = item.get()
            if value != 'Keep Same':
                value = set_to[values.index(value)]
                keybinds[key] = int(value)
                with open('keys.json', 'w') as file:
                    json.dump(keybinds, file)

    def update_keybind(key, value):
        if value != 'N/A':
            keybinds[key] = value
            with open('keys.json', 'w') as file:
                json.dump(keybinds, file)
    
    def reset_keys():
        with open('defults.json', 'r') as f:
            with open('keys.json', 'w') as f2:
                f2.write(f.read())
                f2.close()
            f.close()
        with open('keys.json', 'r') as file:
            keybinds = json.load(file)
    root = tk.Tk()
    root.title("Keybind Editor")

    all_binds = list(keybinds.keys())
    values = ["Keep Same", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'LShift', 'Caps', 'Ctrl', 'Space', 'Up Arrow', 'Left Arrow', 'Down Arrow', 'Right Arrow']
    number_to = ('N/A',97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,49,50,51,52,53,54,55,56,57,48,1073742049,1073741881,1073742048,32,1073741906,1073741904,1073741905,1073741903)
    set_to=('N/A',
        pygame.K_a,
        pygame.K_b,
        pygame.K_c,
        pygame.K_d,
        pygame.K_e,
        pygame.K_f,
        pygame.K_g,
        pygame.K_h,
        pygame.K_i,
        pygame.K_j,
        pygame.K_k,
        pygame.K_l,
        pygame.K_m,
        pygame.K_n,
        pygame.K_o,
        pygame.K_p,
        pygame.K_q,
        pygame.K_r,
        pygame.K_s,
        pygame.K_t,
        pygame.K_u,
        pygame.K_v,
        pygame.K_w,
        pygame.K_x,
        pygame.K_y,
        pygame.K_z,
        pygame.K_1,
        pygame.K_2,
        pygame.K_3,
        pygame.K_4,
        pygame.K_5,
        pygame.K_6,
        pygame.K_7,
        pygame.K_8,
        pygame.K_9,
        pygame.K_0,
        pygame.K_LSHIFT,
        pygame.K_CAPSLOCK,
        pygame.K_LCTRL,
        pygame.K_SPACE,
        pygame.K_UP,
        pygame.K_LEFT,
        pygame.K_DOWN,
        pygame.K_RIGHT,
    )

    # Tab Control Setup
    notebook = ttk.Notebook(root)
    movement_tab = ttk.Frame(notebook)
    weapons_tab = ttk.Frame(notebook)
    notebook.add(movement_tab, text="Movement")
    notebook.add(weapons_tab, text="Weapons")
    notebook.pack(expand=True, fill="both")

    def create_dropdowns(tab, keys):
        dropdowns = []
        for i, key in enumerate(keys):
            label = tk.Label(tab, text=key)
            label.grid(row=i, column=0)

            dropdown = ttk.Combobox(tab, values=values)
            dropdown.set(values[number_to.index(keybinds[key])])
            dropdown.grid(row=i, column=1)
            dropdowns.append(dropdown)
        return dropdowns
    
    
    movement_keys = movement_keys = all_binds[:6]
    weapon_keys = all_binds[6:]
    movement_dropdowns = create_dropdowns(movement_tab, movement_keys)
    weapon_dropdowns = create_dropdowns(weapons_tab, weapon_keys)
    dropdowns  = movement_dropdowns + weapon_dropdowns

    save_btn = tk.Button(root, text='Save', command=save_keybind)
    save_btn.pack(side=tk.LEFT)
    quit_btn = tk.Button(root, text='Quit', command=root.destroy)
    quit_btn.pack(side=tk.LEFT)
    reset_btn = tk.Button(root, text='Reset', command=reset_keys)
    reset_btn.pack(side=tk.LEFT)

    root.mainloop()
