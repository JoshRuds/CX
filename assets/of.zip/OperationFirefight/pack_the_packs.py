import shutil
import os
import inspect
import importlib.util
import sys

# Your project's directory (where this script is)
project_dir = os.path.dirname(os.path.abspath(__file__))

# Your imports (edit here if you add more in the future)
user_imports = [
    "pygame", "math", "random", "os", "time", "json"
]

# Built-in Python modules (don't need to be bundled)
# You could fetch this dynamically, but we'll hardcode common ones
builtin_modules = set(sys.builtin_module_names)

# Function to check if a module is built-in or installed
def is_builtin_or_installed(mod_name):
    if mod_name in builtin_modules:
        return "builtin"
    spec = importlib.util.find_spec(mod_name)
    if spec is None:
        return "missing"
    if "site-packages" in (spec.origin or ""):
        return "external"
    return "builtin"

# Copy pygame if needed
def bundle_pygame():
    try:
        import pygame
        pygame_path = os.path.dirname(inspect.getfile(pygame))
        dest_path = os.path.join(project_dir, "pygame")

        if not os.path.exists(dest_path):
            print(f"Copying pygame from {pygame_path} to {dest_path}...")
            shutil.copytree(pygame_path, dest_path)
            print("✅ Pygame bundled successfully.")
        else:
            print("ℹ️  Pygame folder already exists in the project.")
    except ImportError:
        print("❌ Pygame is not installed on this machine. Please install it with 'pip install pygame' and rerun this script.")

# Run checks
def main():
    print("🔍 Checking dependencies...\n")
    for mod in user_imports:
        status = is_builtin_or_installed(mod)
        if status == "builtin":
            print(f"✅ {mod} is a built-in module.")
        elif status == "external":
            print(f"📦 {mod} is an external package and may need bundling.")
            if mod == "pygame":
                bundle_pygame()
        else:
            print(f"❌ {mod} is missing! This script may not run correctly.")

if __name__ == "__main__":
    main()