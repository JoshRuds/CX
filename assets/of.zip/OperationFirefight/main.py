import sys
sys.path.insert(0, './pygame') # Use local copy of pygame if pip isn't available

# External imports:
import pygame
import math
import random
import os
import time
import json

# Initialize Pygame
pygame.init()
pygame.font.init()
pygame.mixer.init()

# Internal imports
import data.home_screen as home_screen
from data.guns import *
from data.settings import *
from launcher import launcher
from edit_keys import edit_keys
import data.mission_selector as mision_selector

'''with open('binaries/exists.bin', 'rb') as f:
    read = f.read(1)
    if read == b'1': pass
    elif read == b'0': import __init__ as _; _ = None
    else: raise UnexpectedBinaryError('binaries/exists.bin')

try:
    open('save_data.dat', 'x')
except FileExistsError:
    pass
try:
    open('filekey.key', 'x')
    # string the key in a file
    from cryptography.fernet import Fernet
    key = Fernet.generate_key()
    with open('filekey.key', 'wb') as filekey:
        filekey.write(key)
except FileExistsError:
    pass
'''

while True:
    result = launcher()
    if result == None:
        pygame.quit()
        sys.exit()
    elif result == False:
        edit_keys()
        continue
    elif result == True:
        break

# Set screen dimensions
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption(TITLE)

# Game clock
clock = pygame.time.Clock()
old_speed = player_speed
#map_layout = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1], [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1], [1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1], [1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1], [1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]

# Load the MP3 file
pygame.mixer.music.load("sound/steps.mp3")


def load_animation(folder, base_filename, count):
    return [
        pygame.image.load(os.path.join(folder, f"{base_filename}{i}.png")).convert()
        for i in range(count)
    ]

death_ani = load_animation("assets/game_over", "image00001-", 60)
shop_ani = load_animation("assets/shop_scrn", "shop-", 15)

gold_coin = pygame.image.load(os.path.join('assets', 'gold_coin.png')).convert()
gold_coin = pygame.transform.scale(gold_coin, COIN_SIZE)
silver_coin = pygame.image.load(os.path.join('assets', 'silver_coin.png')).convert()
silver_coin = pygame.transform.scale(silver_coin, COIN_SIZE)
bronze_coin = pygame.image.load(os.path.join('assets', 'bronze_coin.png')).convert()
bronze_coin = pygame.transform.scale(bronze_coin, COIN_SIZE)

target_cursor = pygame.image.load(os.path.join('assets', 'cursor.png')).convert_alpha()
target_cursor = pygame.transform.scale(target_cursor, (32,32))

muzzle_flash = pygame.image.load(os.path.join('assets', 'flash.png')).convert_alpha()
muzzle_flash = pygame.transform.scale(muzzle_flash, (32,32))
# Function to play the sound
def play_sound():
    pygame.mixer.music.play(-1)

GOLD = 0
SILVER = 0
BRONZE = 0

with open('keys.json', 'r') as file:
        keybinds = json.load(file)

def play(sound):
    pygame.mixer.Sound.play(sound)

class Player:
    def __init__(self, x, y, color, screen):
        self.x = x
        self.y = y
        self.color = color
        self.angle = 0
        self.bullets_remaining = GUNS.GLOCK.CLIP
    
    def dash(self):
        rad = math.radians(self.get_mouse_angle())
        dx = math.cos(rad)
        dy = math.sin(rad)
        self.move(dx,dy,100)

    def move(self, dx, dy, speed = player_speed):
        new_x = self.x + dx * speed
        new_y = self.y + dy * speed

        # Check for wall collisions
        if not self.collides_with_wall(new_x, self.y):
            self.x = new_x
        if not self.collides_with_wall(self.x, new_y):
            self.y = new_y

    def collides_with_wall(self, x, y):
        grid_x = int(x // TILE_SIZE)
        grid_y = int(y // TILE_SIZE)
        return map_layout[grid_y][grid_x] == 1

    def draw(self):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), player_size)

        # Fog of war
        pygame.draw.circle(screen, COLOURS.BLACK, (int(self.x), int(self.y)), fov_radius, 1)
    
    def get_mouse_angle(self):
        mouse_x = pygame.mouse.get_pos()[0]
        mouse_y = pygame.mouse.get_pos()[1]
        angle = math.atan2(mouse_y - self.y, mouse_x - self.x)
        angle = angle * (180 / math.pi)
        return angle

    def shoot(self, shotgun: bool, max_offset: int, scoping: bool, all_bullets: pygame.sprite.Group):
        self.bullets_remaining -= 1
        if shotgun:
            
            for i in range(11):
                angle=1*(i-5) if not scoping else (1*(i-5))/2
                rad = math.radians(self.get_mouse_angle() + angle)
                dx = math.cos(rad) * bullet_speed
                dy = math.sin(rad) * bullet_speed
                bullets.append(Bullet(self.x, self.y, dx, dy, self.color, screen))
        else:
            angle=random.randint(0,max_offset) if not scoping else (random.randint(0,max_offset))/2
            if random.choice([True,False]):
                rad = math.radians(self.get_mouse_angle() + angle)
            else:
                rad = math.radians(self.get_mouse_angle() - angle)
            dx = math.cos(rad) * bullet_speed
            dy = math.sin(rad) * bullet_speed
            to_add = Bullet(self.x, self.y, dx, dy, self.color)
            bullets.append(to_add)
            all_bullets.add(to_add)
    
    def get_bullets_remaining(self):
        return self.bullets_remaining
    
    def set_bullets_remaining(self, to: int):
        self.bullets_remaining = to
        

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, dx, dy, color):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
        self.color = color

    def update(self):
        self.x += self.dx
        self.y += self.dy

    def collides_with_wall(self, x, y):
        grid_x = int(x // TILE_SIZE)
        grid_y = int(y // TILE_SIZE)
        return map_layout[grid_y][grid_x] == 1

    def draw(self):
        #body = pygame.Rect(self.x, self.y, 20, 30)
        #body = pygame.transform.rotate(body, self.get_mouse_angle())
        pygame.draw.circle(screen, self.color, (self.x, self.y), 5)

    def get_mouse_angle(self):
        mouse_x = pygame.mouse.get_pos()[0]
        mouse_y = pygame.mouse.get_pos()[1]
        angle = math.atan2(mouse_y - self.y, mouse_x - self.x)
        angle = angle * (180 / math.pi)
        return angle

    def is_out_of_bounds(self):
        return not (0 <= self.x <= WIDTH and 0 <= self.y <= HEIGHT)

class Enemy:
    def __init__(self, x, y, player, walls, all_bul):
        self.x = x
        self.y = y
        self.player = player
        self.walls = walls
        self.color = COLOURS.ORANGE
        self.speed = player_speed//2
        self.last_tick = False
        self.angle = 0
        self.gun = random.choice(list_of_guns)
        self.cooldown_max = math.floor(FPS / self.gun.MAX_SHOTS_A_SECOND)
        self.cooldown = 0
        self.bullets = self.gun.CLIP
        self.all_bullets = all_bul
    
    def shoot_at_player(self):
        if self.bullets <= 0 or self.cooldown > 0:
            return
        angle = math.atan2(self.player.y - self.y, self.player.x - self.x)
        dx = bullet_speed * math.cos(angle)
        dy = bullet_speed * math.sin(angle)
        bullet_to_add = Bullet(self.x, self.y, dx, dy, self.color)
        bullets.append(bullet_to_add)
        self.all_bullets.add()
        self.cooldown = self.cooldown_max
        self.bullets -= 1
        

    def move_if_not_visible(self):
        if self.last_tick:# visible last tick
            self.angle = random.random()*2
        angle = self.angle
        new_x = self.x + self.speed * math.cos(angle)
        new_y = self.y + self.speed * math.sin(angle)

        # Check for wall collisions
        if not self.collides_with_wall(new_x, self.y):
            self.x = new_x
            self.last_tick = False
        if not self.collides_with_wall(self.x, new_y):
            self.y = new_y
            self.last_tick = False
            return
        self.last_tick = True

    def move_if_visible(self):
        if not is_visible((self.x,self.y), (self.player.x, self.player.y), self.walls):
            self.move_if_not_visible()

        angle = math.atan2(self.player.y - self.y, self.player.x - self.x)
        new_x = self.x + self.speed * math.cos(angle)
        new_y = self.y + self.speed * math.sin(angle)

        # Check for wall collisions
        if not self.collides_with_wall(new_x, self.y):
            self.x = new_x
        if not self.collides_with_wall(self.x, new_y):
            self.y = new_y
        self.last_tick = True

        self.shoot_at_player()

    def collides_with_wall(self, x, y):
        grid_x = int(x // TILE_SIZE)
        grid_y = int(y // TILE_SIZE)
        return map_layout[grid_y][grid_x] == 1

    def draw(self):
        pygame.draw.circle(screen, self.color, (self.x,self.y), player_size)

    def update(self):
        self.move_if_visible()
        self.cooldown -= 1

def draw_map():
    walls = []
    for y, row in enumerate(map_layout):
        for x, tile in enumerate(row):
            if tile == 1:
                walls.append(pygame.draw.rect(screen, COLOURS.GRAY, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)))
    return walls

# Setup Font
font = pygame.font.Font('freesansbold.ttf', 74)
shop_font = pygame.font.Font('freesansbold.ttf', 52)
small_font = pygame.font.Font('freesansbold.ttf', 36)
# Define the pause menu
def display_pause_menu():
    screen.fill(COLOURS.BLACK)

    # Display "Paused" text
    paused_text = font.render("Paused", True, COLOURS.WHITE)
    screen.blit(paused_text, (WIDTH // 2 - paused_text.get_width() // 2, HEIGHT // 2 - 100))

    # Display "Press P to resume"
    resume_text = small_font.render("Press P to resume", True, COLOURS.WHITE)
    screen.blit(resume_text, (WIDTH // 2 - resume_text.get_width() // 2, HEIGHT // 2))

    # Display "Press Q to quit"
    quit_text = small_font.render("Press Q to quit", True, COLOURS.WHITE)
    screen.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT // 2 + 50))

'''def game_over():
    for img in death_ani:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                break
        bg = pygame.transform.scale(img, (WIDTH, HEIGHT))
        screen.blit(bg, (0,0))
        pygame.display.flip()
        clock.tick(10)
    time.sleep(5)'''
    
def shop():
    while True:
        for img in shop_ani:
            bg = pygame.transform.scale(img, (WIDTH, HEIGHT))
            screen.blit(bg, (0,0))
            screen.blit(gold_coin, (0, HEIGHT-52))
            screen.blit(silver_coin, (0, HEIGHT-114))
            screen.blit(bronze_coin, (0, HEIGHT-176))

            printable = str(GOLD)
            text = shop_font.render(printable, True, COLOURS.RED)
            textRect = text.get_rect()
            textRect.topleft = (60,HEIGHT-52)
            screen.blit(text, textRect)
            printable = str(SILVER)
            text = shop_font.render(printable, True, COLOURS.RED)
            textRect = text.get_rect()
            textRect.topleft = (60,HEIGHT-114)
            screen.blit(text, textRect)
            printable = str(BRONZE)
            text = shop_font.render(printable, True, COLOURS.RED)
            textRect = text.get_rect()
            textRect.topleft = (60,HEIGHT-176)
            screen.blit(text, textRect)
            pygame.display.flip()
            clock.tick(8)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        return True

def print_screen(text, area, x, y, color=COLOURS.RED):
    printable = str(text)
    text = small_font.render(printable, True, COLOURS.RED)
    text.set_colorkey(color)
    textRect = text.get_rect()
    exec(f'textRect.{area} = ({x},{y})')
    return text, textRect

def line_intersects(p1, p2, p3, p4):
    p1 = pygame.math.Vector2(p1)
    p2 = pygame.math.Vector2(p2)
    p3 = pygame.math.Vector2(p3)
    p4 = pygame.math.Vector2(p4)

    d1 = p2 - p1
    d2 = p4 - p3
    denom = d1.x * d2.y - d1.y * d2.x
    
    if denom == 0:
        return False  # Lines are parallel

    t = ((p3.x - p1.x) * d2.y - (p3.y - p1.y) * d2.x) / denom
    u = ((p3.x - p1.x) * d1.y - (p3.y - p1.y) * d1.x) / denom

    return 0 <= t <= 1 and 0 <= u <= 1

def is_visible(player_pos, enemy_pos, walls):
    player_pos = pygame.math.Vector2(player_pos)
    enemy_pos = pygame.math.Vector2(enemy_pos)
    
    for wall in walls:
        # Check all four edges of the rectangle
        corners = [
            wall.topleft,
            wall.topright,
            wall.bottomright,
            wall.bottomleft
        ]
        
        edges = [
            (corners[0], corners[1]),  # Top
            (corners[1], corners[2]),  # Right
            (corners[2], corners[3]),  # Bottom
            (corners[3], corners[0])   # Left
        ]
        
        for edge in edges:
            if line_intersects(player_pos, enemy_pos, edge[0], edge[1]):
                return False
    
    return True
def rotate_surface_towards_mouse(surface, position):
    # Get the current mouse position
    mouse_x, mouse_y = pygame.mouse.get_pos()
    
    # Calculate the angle between the surface position and the mouse position
    angle = math.degrees(math.atan2(mouse_y - position[1], mouse_x - position[0]))
    
    # Rotate the surface
    rotated_surface = pygame.transform.rotate(surface, -angle)
    
    # Get the new rectangle for the rotated surface
    new_rect = rotated_surface.get_rect(center=position)
    
    return rotated_surface, new_rect
# Main game loop
#   
def main(letter:str):
    moved = False
    pygame.cursors.Cursor(pygame.SYSTEM_CURSOR_CROSSHAIR)
    play_sound()
    player = Player(WIDTH // 2, HEIGHT // 2, COLOURS.BLUE, screen)
    while player.collides_with_wall(player.x,player.y):
        player.y-=5
    cooldown = 0
    dash_cool = 0
    empty = 0
    laser = False
    gun = GUNS.GLOCK
    shooting = False
    paused = False
    RELOAD = pygame.mixer.Sound(os.path.join('sound', 'RELOAD.mp3'))
    pygame.mouse.set_visible(False)
    all_bullets = pygame.sprite.Group()
    flashes = []
    running = True
    enemys = []
    pygame.display.set_caption(TITLE)
    while running:
        player_speed = 5
        moved = False
        searching = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_0:
                    safe = True  # Toggle pause state
                '''if event.key == keybinds['Suicide']:
                    game_over()
                    pygame.quit()
                    quit()'''
                if event.key == pygame.K_ESCAPE:
                    printable = f'Name: {gun.NAME}\nShotgun: {gun.SHOTGUN}'
                    text = small_font.render(printable, True, COLOURS.RED)
                    textRect = text.get_rect()
                    textRect.center = ((WIDTH//2, HEIGHT//2))
                    screen.blit(text, textRect)
            
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  
                shooting = True
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 2:
                #enemys.append(event.pos)
                enemy = Enemy(event.pos[0], event.pos[1],player, maps, all_bullets)
                enemys.append(enemy)
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                shooting = False
    
        # Halve the player speed if the right mouse button is down
        if pygame.key.get_mods() & pygame.KMOD_CAPS:  # Caps down
            current_speed = player_speed / 2
            scoping = True
        else:
            current_speed = player_speed
            scoping = False


        if shooting and cooldown == 0:
            if bullets_left > 0:
                player.shoot(gun.SHOTGUN, gun.MAX_OFFSET, scoping, all_bullets)
                cooldown = math.floor(FPS / gun.MAX_SHOTS_A_SECOND)
                flashes.append([player.x, player.y, 5])

                play(gun.SOUND)
            else:
                empty = 30
                play(pygame.mixer.Sound(os.path.join('sound', 'EMPTY.mp3')))

        
        
        if searching:
            printable = f'Name: {gun.NAME}\nShotgun: {gun.SHOTGUN}'
            text = small_font.render(printable, True, COLOURS.RED)
            textRect = text.get_rect()
            textRect.center = ((WIDTH//2, HEIGHT//2))
            screen.blit(text, textRect)
        
                    
        screen.fill(COLOURS.BLACK)
        maps = draw_map()
        
        # Print Bullets Remaining to screen
        
        bullets_left = player.get_bullets_remaining()    
        text, textRect = print_screen(str(bullets_left),'topright',WIDTH,0,COLOURS.RED)
        screen.blit(text,textRect)

        # Print Cooldown to screen
        printable = str(cooldown).removesuffix('.0')
        text = small_font.render(printable, True, COLOURS.RED)
        textRect = text.get_rect()
        textRect.topleft = (0, 0)
        screen.blit(text, textRect)

        printable = ('Operation ' + nato_alphabet[letter]).upper()
        text = small_font.render(printable, True, COLOURS.RED)
        textRect = text.get_rect()
        textRect.bottomleft = (0, HEIGHT)
        screen.blit(text, textRect)

        screen.blit(target_cursor, (pygame.mouse.get_pos()[0]-target_cursor.get_width()//2, pygame.mouse.get_pos()[1]-target_cursor.get_height()//2))
        if laser:
            pygame.draw.line(screen, COLOURS.RED, (player.x, player.y), pygame.mouse.get_pos(), 1)
        

        # Print Gun Name to screen
        printable = gun.NAME
        text = small_font.render(printable, True, COLOURS.RED)
        textRect = text.get_rect()
        textRect.bottomright = (WIDTH, HEIGHT)
        screen.blit(text, textRect)

        # Movement
        keys = pygame.key.get_pressed()
        if keys[pygame.K_l]:
            laser = True
        if keys[pygame.K_k]:
            laser = False
        if keys[keybinds['Up']]:
            player.move(0, -1, current_speed)
            moved = True
        if keys[keybinds['Down']]:
            player.move(0, 1, current_speed)
            moved = True
        if keys[keybinds['Left']]:
            player.move(-1, 0, current_speed)
            moved = True
        if keys[keybinds['Right']]:
            player.move(1, 0, current_speed)
            moved = True
        if keys[pygame.K_r]:
            player.set_bullets_remaining(gun.CLIP)
            cooldown = math.floor(FPS * gun.RELOAD)
        if keys[keybinds['Dash']]:
            if dash_cool == 0:
                player.dash()
                dash_cool = FPS*10 #10 sec
        if keys[keybinds['Glock']]:
            gun = GUNS.GLOCK
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[keybinds['Ak47']]:
            gun = GUNS.AK47
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[keybinds['Eaglepoint']]:
            gun = GUNS.EAGLEPOINT
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[keybinds['Scar']]:
            gun = GUNS.SCAR
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[keybinds['M4A1']]:
            gun = GUNS.M4A1
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[keybinds['Remington']]:
            gun = GUNS.REMINGTON
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[keybinds['Browning']]:
            gun = GUNS.BROWNING
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)
        if keys[keybinds['Revolver']]:
            gun = GUNS.REVOLVER
            cooldown = gun.RELOAD*FPS
            player.set_bullets_remaining(gun.CLIP)

        # Bullet update#
        all_bullets.update()
        for bullet in bullets[:]:
            if bullet.is_out_of_bounds() or bullet.collides_with_wall(bullet.x, bullet.y):
                bullets.remove(bullet)
            bullet.draw()

        '''
        for i, [x, y, time_left] in enumerate(flashes):
            screen.blit(rotate_surface_towards_mouse(muzzle_flash,(player.x, player.y))[0], (player.x, player.y))
            flashes[i][1] = time_left - 1
            if time_left <= 0:
                flashes.pop(i)'''

        # Draw player
        player.draw()

        if not moved:
            pygame.mixer.music.pause()
        
        if moved:
            pygame.mixer.music.unpause()

        
        for i in enemys:
            i.update()
            if is_visible((player.x, player.y), (i.x,i.y), maps):
                i.draw()

        if cooldown > 0:
            cooldown -= 1
        if dash_cool > 0:
            dash_cool -= 1
        if empty > 0:
            printable = 'EMPTY'
            text = font.render(printable, True, COLOURS.RED)
            textRect = text.get_rect()
            textRect.center = (WIDTH//2, HEIGHT//2)
            screen.blit(text, textRect)
            empty -= 1
        pygame.display.flip()
        clock.tick(FPS)


if __name__ == "__main__":
    bg_path = os.path.join('assets', 'home_scrn.jpg')
    bg = pygame.image.load(bg_path)
    bg = pygame.transform.scale(bg, (WIDTH, HEIGHT))
    screen.blit(bg, (0,0))
    pygame.display.flip()
    time.sleep(3)
    while True:
        if not home_screen.go(pygame,sys,os):
            if shop():
                continue
        else: 
            result_mission = mision_selector.go(pygame,sys,os)
            main(result_mission)